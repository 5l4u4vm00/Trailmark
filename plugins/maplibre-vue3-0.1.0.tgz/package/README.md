# maplibre-vue3

Tiny Vue 3 + MapLibre GL composable for managing one or more keyed map instances with a ready-promise and lifecycle-aware `onMapReady` hook.

## Install

This package is consumed locally for now (no registry publish). From the consumer's `package.json`:

```json
{
  "dependencies": {
    "maplibre-vue3": "file:../maplibre-vue3"
  }
}
```

Peer deps: `vue ^3.5`, `maplibre-gl ^5`.

## Usage

```ts
import { useMap, onMapReady } from 'maplibre-vue3';

// In the component that owns the canvas (uses the default key 'main'):
const { init, destroy } = useMap();
onMounted(() => init(container.value, { style, center, zoom }));
onBeforeUnmount(() => destroy());

// Anywhere else (in <script setup>):
onMapReady((map) => {
  const sync = () => doSomething(map.getBearing());
  map.on('rotate', sync);
  return () => map.off('rotate', sync);
});

// For additional maps (e.g. a panel map), pass your own string key:
const panel = useMap('panelA');
```

## API

- `useMap(key?)` → `{ map, whenMapReady, onMapReady, init, destroy }`. `key` defaults to `'main'`.
- `onMapReady(fn)` — shortcut bound to the default key; `fn` may return a cleanup that runs on unmount.

## Build

```sh
npm install
npm run build
```

Outputs `dist/index.js` (ESM), `dist/index.cjs`, and `dist/index.d.ts`. `vue` and `maplibre-gl` are externalised.
